Team Services REST API and .Net Client Library Sample Code
===================

This repo contains code samples for using the REST API's and .Net Client Libraries in Team Services. Code is optimized to be simple and easy to understand.

Feel free to contribute and/or provide feedback. 

﻿namespace VstsRestApiSamples.ViewModels.ProjectsAndTeams
{
    public class TeamPost
    {
        public string name { get; set; }
        public string description { get; set; }
    }
}

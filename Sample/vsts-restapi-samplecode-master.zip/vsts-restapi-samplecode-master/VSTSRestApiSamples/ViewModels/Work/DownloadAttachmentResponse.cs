﻿namespace VstsRestApiSamples.ViewModels.Work
{
    public class DownloadAttachmentResponse : BaseViewModel
    {
        public string file { get; set; }
    }
}

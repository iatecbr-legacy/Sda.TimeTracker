Thank you for your pull request!
By completing this pull request, you agree to the [Contributing License Agreement](https://github.com/ALM-Rangers/Work-Item-Details-Widget-Extension/blob/master/.github/CLA.md).

Fixes # .

Changes proposed in this pull request:  
- 
- 
- 

@ALM-Rangers/workitemdetails